var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var gol1 = createSprite(200,28,100,20);
gol1.shapeColor=("yellow");

var gol2 = createSprite(200,372,100,20);
gol2.shapeColor=("yellow");

var atacante = createSprite(200,200,10,10);
atacante.shapeColor = ("white");

var tacoJogador = createSprite(200,50,50,10);
tacoJogador.shapeColor = "black";

var tacoComputador = createSprite(200,350,50,10);
tacoComputador.shapeColor = "black";

var linha1 = createSprite(350,50,5,800);

var linha2 = createSprite(50,400,5,800);

var linha3 = createSprite(200,28,800,5);

var linha4 =createSprite(200,372,800,5);
var estadojogo = "sacar";

createEdgeSprites(topEdge);
createEdgeSprites(BOTTOM);
createEdgeSprites(rightEdge);
createEdgeSprites(leftEdge);

 

function sacar() {
  atacante.velocityX = 10;
  atacante.velocityY = 5;
}
function redefinir(){
  atacante.x = 200;
  atacante.y = 200;
  atacante.velocityX = 0;
  atacante.velocityY = 0;
}
function draw() {
  background("green");
  drawSprites();
  
    if (keyDown("space") && estadojogo === "sacar"){
    sacar();
    
  }
  if(atacante.isTouching(tacoJogador)||atacante.isTouching(tacoComputador)){
     playSound("assets/category_bell/hollow_bell_notification.mp3");
    
  }
  if(atacante.isTouching(gol1)||atacante.isTouching(gol2)){
    playSound("assets/category_bell/notification_4.mp3");
    
  }
  tacoJogador.velocityX = 0;
  tacoJogador.velocityY = 0;
  
  if(keyDown(LEFT_ARROW)){
    tacoJogador.velocityX = -10;
    tacoJogador.velocityY= 0;
  }
  if (keyDown(RIGHT_ARROW)){
    tacoJogador.velocityX = 10;
    tacoJogador.velocityY = 0;
  }
  
 
  tacoComputador.x = atacante.x;
   atacante.bounceOff(tacoJogador);
   atacante.bounceOff(tacoComputador);
   atacante.bounceOff(edges);
   tacoJogador.bounceOff(rightEdge);
   tacoJogador.bounceOff(leftEdge);
   
 for (var i = 0; i < 400; i=i+20 ){
    line (i,200,i+10,200);
  }  
    
  if(atacante.isTouching(gol1) || atacante.isTouching(gol2) ){
    redefinir();
    estadojogo = "sacar";
  }
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
